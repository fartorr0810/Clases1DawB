package com.jacaranda.tamano;

public class LecturaJson {

	Comunidad dato;

	public Comunidad getDato() {
		return dato;
	}

	public void setDatos(Comunidad dato) {
		this.dato = dato;
	}
	
	
	
}
