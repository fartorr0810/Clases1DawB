package com.jacaranda.tamano;

public class ComunidadDescripcionException extends Exception {
	
	public ComunidadDescripcionException() {
		super("No se encuentra la comunidad y descripcion introducidas");
	}

}
