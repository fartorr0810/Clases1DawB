package poo;

public class Estudiante extends Persona {

}
