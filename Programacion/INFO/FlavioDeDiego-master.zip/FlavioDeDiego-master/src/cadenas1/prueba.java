package cadenas1;

public class prueba {

	public static void main(String[] args) {
		
		
		StringBuilder prueba= new StringBuilder("C");
		
		Character.isLowerCase('c');
		
		System.out.println(Character.isLowerCase('C'));
		System.out.println(prueba);
		}

}
