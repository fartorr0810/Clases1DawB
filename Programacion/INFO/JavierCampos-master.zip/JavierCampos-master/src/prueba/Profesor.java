package prueba;

public class Profesor extends persona {
	private String tutoria;

}
