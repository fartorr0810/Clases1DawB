package ejercicio2;

public class Main {

}
