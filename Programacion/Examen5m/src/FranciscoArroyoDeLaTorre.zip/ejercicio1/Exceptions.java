package ejercicio1;

public class Exceptions extends Exception {

}
