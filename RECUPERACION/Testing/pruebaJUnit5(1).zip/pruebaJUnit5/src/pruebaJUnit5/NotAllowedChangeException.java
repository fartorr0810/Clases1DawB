package pruebaJUnit5;

public class NotAllowedChangeException extends Exception{
	public NotAllowedChangeException(String message) {
		super(message);
	}

}
