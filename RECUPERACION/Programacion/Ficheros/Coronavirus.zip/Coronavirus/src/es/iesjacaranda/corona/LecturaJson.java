package es.iesjacaranda.corona;



public class LecturaJson {

	ClaseDatos Datos;
	
	public ClaseDatos getDatos() {
		return Datos;
	}
	public void setDatos(ClaseDatos datos) {
		Datos = datos;
	}
	
	
	
	
	
	
	
}
