package feria;

public enum ClaseCaseta {
	FAMILIAR, ENTIDAD, DISTRITO, MUNICIPAL, SERVICIOS;
}
