package feria;

public class GenerarJson {
public GenerarJson() {
	
}
}
