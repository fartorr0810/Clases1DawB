package ejercicio;

public enum ClaseCaseta {
	FAMILIAR,ENTIDAD,DISTRITO,MUNICIPAL,SERVICIOS;
}
