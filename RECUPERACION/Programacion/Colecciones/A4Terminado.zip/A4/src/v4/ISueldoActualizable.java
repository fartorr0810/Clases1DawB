package v4;

public interface ISueldoActualizable {
	public void sueldoActualizable();
}
