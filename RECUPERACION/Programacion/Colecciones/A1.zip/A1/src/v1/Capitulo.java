package v1;

public class Capitulo {
	private String nombre;

	public Capitulo(String nombre) {
		super();
		this.nombre = nombre;
	}
}
