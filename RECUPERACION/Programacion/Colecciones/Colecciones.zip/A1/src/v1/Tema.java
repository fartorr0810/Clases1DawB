package v1;

public enum Tema {
	DRAMA,COMEDIA,INTRIGA,CIENCIAFICCION;
}
