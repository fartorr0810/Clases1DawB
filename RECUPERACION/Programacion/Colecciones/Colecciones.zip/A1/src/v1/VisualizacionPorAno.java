package v1;

public interface VisualizacionPorAno  {
	public float getMediaVisualizaciones();
}
