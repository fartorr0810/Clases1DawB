package v3;

public enum Tipogenerador {
	FOTOVOLTAICO,SOLAR,HIBRIDO;
}
