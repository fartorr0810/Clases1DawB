package v3;

public interface Monetizable {
	public float dinerogenerado(float precio);
}
