module A2 {
}