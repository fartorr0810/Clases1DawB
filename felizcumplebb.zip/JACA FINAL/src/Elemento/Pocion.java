package Elemento;

public class Pocion extends Elemento {
	
	public Pocion () {
		super(logicaJuego.Constantes.POCION);
	}
	
	
	//TOSTRING
}
