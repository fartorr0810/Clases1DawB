package Elemento;

public class Arbol extends Elemento {


	public Arbol () {
		super(logicaJuego.Constantes.ARBOL);
	}
	
	
	//TOSTRING
}
