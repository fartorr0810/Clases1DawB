package Elemento;

public class Gema extends Elemento {
	
	
	public Gema () {
		super(logicaJuego.Constantes.GEMA);
	}
	
	//TOSTRING
}
