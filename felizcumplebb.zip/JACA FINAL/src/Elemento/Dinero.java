package Elemento;

public class Dinero extends Elemento {

	//COMO LE INDICO QUE EL SIMBOLO ES D
	
	public Dinero () {
		super(logicaJuego.Constantes.DINERO);
		
		
	}
	
	
	
	
	//TOSTRING
	
}
