package Elemento;

public class Roca extends Elemento {
	
	public Roca () {
		super(logicaJuego.Constantes.POCION);
	}
	
	
	//TOSTRING
	
}
