package ejercicio1;

public class Pais {
	public int codPais;
	private String descripcion;
	public Pais(int codPais, String descripcion) {
		super();
		this.codPais = codPais;
		this.descripcion = descripcion;
	}
}
