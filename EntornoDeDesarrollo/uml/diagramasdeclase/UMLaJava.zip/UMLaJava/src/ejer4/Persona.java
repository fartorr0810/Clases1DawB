package ejer4;

public class Persona {
	public java.util.Collection secasa=new java.util.TreeSet<>();
	public java.util.Collection escasada=new java.util.TreeSet<>();

}
