package ejer7;

public class Libro {
	private String isbn;
	private String titulo;
	private String editorial;
}
