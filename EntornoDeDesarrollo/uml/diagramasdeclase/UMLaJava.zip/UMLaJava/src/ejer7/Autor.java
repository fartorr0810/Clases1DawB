package ejer7;

public class Autor {
	private String autor;
}
