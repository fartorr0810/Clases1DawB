package ejer7;

public class Usuario {

}
