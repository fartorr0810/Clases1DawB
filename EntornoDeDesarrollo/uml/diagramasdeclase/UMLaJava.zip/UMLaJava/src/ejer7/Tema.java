package ejer7;

public class Tema {
	private String descripcion;
	public java.util.Collection tema=new java.util.TreeSet<>();
	public java.util.Collection perteneceatema=new java.util.TreeSet<>();
}
