package ejer7;

import java.util.Date;

public class Comentario {
	private Date fecha=new Date();
	private String texto;
	private double puntuacion;
	public Usuario comentario=new Usuario();
}
