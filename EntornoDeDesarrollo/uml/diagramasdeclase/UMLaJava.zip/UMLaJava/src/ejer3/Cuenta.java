package ejer3;

public class Cuenta {
	private String cc;
}
