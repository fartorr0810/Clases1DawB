package ejer3;

public class Cliente {
	public String nombre;
	public Cuenta cc;
}
