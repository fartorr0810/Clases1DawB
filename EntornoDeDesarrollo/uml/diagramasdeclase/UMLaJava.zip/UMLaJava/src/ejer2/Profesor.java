package ejer2;

public class Profesor {
	public String nombreprof;
	public Departamento nombredep;
}
