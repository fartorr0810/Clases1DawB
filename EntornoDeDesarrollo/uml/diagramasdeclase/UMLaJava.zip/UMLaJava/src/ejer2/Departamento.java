package ejer2;

public class Departamento {
	public String nombredep;
	public java.util.Collection profesores=new java.util.TreeSet();
}
