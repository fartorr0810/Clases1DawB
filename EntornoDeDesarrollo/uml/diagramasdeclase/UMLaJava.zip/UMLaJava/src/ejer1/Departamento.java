package ejer1;

public class Departamento {
	public String nombreDep;
	public Profesor nombreProf;
}
