package ejer1;

public class Profesor {
	public String nombreProf;
	public Departamento nombreDep;
}
