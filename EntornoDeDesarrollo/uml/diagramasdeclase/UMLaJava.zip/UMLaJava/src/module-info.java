module UMLaJava {
}