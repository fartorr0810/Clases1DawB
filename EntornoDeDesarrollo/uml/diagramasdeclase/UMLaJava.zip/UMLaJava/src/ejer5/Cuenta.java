package ejer5;

import java.util.Date;

public class Cuenta {
	private String ccc;
	private double saldo;
	Date fechaa=new Date();
	public java.util.Collection movimientos=new java.util.TreeSet();
	}
