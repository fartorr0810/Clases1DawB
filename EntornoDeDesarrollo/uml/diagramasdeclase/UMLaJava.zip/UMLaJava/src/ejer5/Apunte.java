package ejer5;

public class Apunte {
	private int numero;
	private String descripcion;
	private double importe;
	
}
