package ejer6;

public class Libro {
	private String isbn;
	private String titulo;
	private String autor;
	private String editorial;
	private int ano;
	public Tema tema=new Tema();
}
