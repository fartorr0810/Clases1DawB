package ejer6;

public class Tema {
	private int id;
	private String descripcion;
	public java.util.Collection tema=new java.util.TreeSet<>();
	public java.util.Collection perteneceatema=new java.util.TreeSet<>();
	}
